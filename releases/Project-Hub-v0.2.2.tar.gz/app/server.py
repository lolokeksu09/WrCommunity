"""Authenticated Project Hub. No Docker socket or shell in this process."""
from __future__ import annotations
from datetime import datetime,timezone
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import hashlib,hmac,json,os,re,secrets,stat,threading,time,sys
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from mfa import read_record, check_otp
STATUS_FILE=Path(os.environ.get('PH_STATUS_FILE','/state/status.json'))
PROJECTS=ROOT/'projects.json'
AUTH_FILE=Path(os.environ.get('PH_AUTH_FILE','/private/auth.json'))
MFA_FILE=Path(os.environ.get('PH_MFA_FILE','/private/totp.json'))
QUEUE_DIR=Path(os.environ.get('PH_QUEUE_DIR','/queue'))
RESULTS_DIR=Path(os.environ.get('PH_RESULTS_DIR','/state/actions'))
ROUTES={'/':('index.html','text/html; charset=utf-8'), '/app.css':('app.css','text/css; charset=utf-8'),
        '/app.js':('app.js','text/javascript; charset=utf-8'),'/favicon.svg':('favicon.svg','image/svg+xml')}
MAX_STATUS_BYTES=262144
SESSION_ABSOLUTE=4*3600
SESSION_IDLE=15*60
LOCK=threading.RLock()
SESSIONS={}
FAILURES={}
# Public Funnel can hide clients behind a shared proxy IP. Bound the table.
MAX_FAILURE_IPS=256
ACTION_COUNTS={}
RID=re.compile(r'^[0-9a-f]{32}$')
CID=re.compile(r'^[0-9a-f]{12}(?:[0-9a-f]{52})?$')
OPS={'start','stop','restart','logs'}
TAILSCALE_HOST=os.environ.get('PH_TAILSCALE_HOST','').strip().lower()
if TAILSCALE_HOST and not re.fullmatch(r'[a-z0-9][a-z0-9.-]{0,240}\.ts\.net',TAILSCALE_HOST):
    raise RuntimeError('PH_TAILSCALE_HOST must be a validated ts.net FQDN')

def load_status(path:Path=STATUS_FILE):
    try:
        with path.open('rb') as f: raw=f.read(MAX_STATUS_BYTES+1)
        if len(raw)>MAX_STATUS_BYTES:raise ValueError('Too large')
        obj=json.loads(raw)
        ts=datetime.fromisoformat(obj['collected_at'].replace('Z','+00:00'))
        if ts.tzinfo is None or obj.get('schema_version')!=1 or not isinstance(obj.get('docker'),dict):raise ValueError('Invalid snapshot')
        age=(datetime.now(timezone.utc)-ts.astimezone(timezone.utc)).total_seconds()
        return {'ok':True,'stale':age>90 or age< -30,'age_seconds':max(0,int(age)),
                'data':{k:v for k,v in obj.items() if k!='_cpu_sample'}}
    except (OSError,ValueError,TypeError,KeyError,json.JSONDecodeError):
        return {'ok':False,'stale':True,'error':'Нет актуальных данных. Проверь systemd timer project-hub-collector.'}

def check_password(password):
    try:
        if AUTH_FILE.is_symlink():return False
        with AUTH_FILE.open('rb') as f:raw=f.read(2049)
        if len(raw)>2048:return False
        record=json.loads(raw)
        if set(record)!={'version','algorithm','n','r','p','salt','digest'}:return False
        if (record['version'],record['algorithm'],record['n'],record['r'],record['p'])!=(1,'scrypt',16384,8,1):return False
        if not isinstance(password,str) or len(password)>256:return False
        salt=bytes.fromhex(record['salt']);digest=bytes.fromhex(record['digest'])
        if len(salt)!=16 or len(digest)!=32:return False
        actual=hashlib.scrypt(password.encode('utf-8'),salt=salt,n=16384,r=8,p=1,dklen=32)
        return hmac.compare_digest(actual,digest)
    except (OSError,TypeError,ValueError,KeyError,MemoryError):return False

def auth_ready():
    try:
        if AUTH_FILE.is_symlink():return False
        with AUTH_FILE.open('rb') as f:record=json.loads(f.read(2049))
        return isinstance(record,dict) and record.get('version')==1 and record.get('algorithm')=='scrypt'
    except (OSError,ValueError,TypeError):return False

def mfa_ready():
    return read_record(MFA_FILE) is not None

def session_for(token):
    if not token or len(token)>128:return None
    digest=hashlib.sha256(token.encode()).hexdigest()
    now=time.monotonic()
    with LOCK:
        s=SESSIONS.get(digest)
        if not s:return None
        if now>s['expires'] or now-s['last']>SESSION_IDLE:
            SESSIONS.pop(digest,None);return None
        s['last']=now
        return (digest,s)

def safe_result(path):
    try:
        if path.is_symlink():return None
        fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
        with os.fdopen(fd,'rb') as f:
            s=os.fstat(f.fileno())
            if not stat.S_ISREG(s.st_mode) or s.st_size>20000:return None
            return json.loads(f.read(20001))
    except (OSError,ValueError,TypeError):return None

class Handler(BaseHTTPRequestHandler):
    server_version='ProjectHub/0.2.2'
    sys_version=''
    def send(self,status,body=b'',mime='application/json; charset=utf-8',cookie=None,head=False):
        self.send_response(status)
        self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
        self.send_header('Permissions-Policy','camera=(), microphone=(), geolocation=()')
        self.send_header('Cross-Origin-Resource-Policy','same-origin')
        self.send_header('Cross-Origin-Opener-Policy','same-origin')
        self.send_header('X-Permitted-Cross-Domain-Policies','none')
        if TAILSCALE_HOST and self.headers.get('Host','').lower()==TAILSCALE_HOST:
            self.send_header('Strict-Transport-Security','max-age=31536000')
        if cookie:self.send_header('Set-Cookie',cookie)
        self.end_headers()
        if not head:self.wfile.write(body)
    def json(self,status,payload,cookie=None,head=False):
        self.send(status,json.dumps(payload,ensure_ascii=False).encode('utf-8'),cookie=cookie,head=head)
    def context(self):
        host=self.headers.get('Host','')
        if not (re.fullmatch(r'(?:127\.0\.0\.1|localhost|\[::1\]):?[0-9]{0,5}',host,re.I) or (TAILSCALE_HOST and host.lower()==TAILSCALE_HOST)):return False
        return True
    def origin_ok(self):
        origin=self.headers.get('Origin','')
        if not origin:return False
        # exact browser origin (protocol, hostname, port); reject cross-site requests
        return (origin=='http://'+self.headers.get('Host','') or (bool(TAILSCALE_HOST) and origin=='https://'+TAILSCALE_HOST))
    def auth(self):
        try:
            cookies=SimpleCookie();cookies.load(self.headers.get('Cookie','')[:2048])
            token=cookies.get('ph_session');return session_for(token.value if token else '')
        except Exception:return None
    def csrf_ok(self,session):
        return bool(session) and hmac.compare_digest(self.headers.get('X-CSRF-Token','')[:128],session[1]['csrf'])
    def read_json(self):
        if self.headers.get('Content-Type','').split(';',1)[0].strip().lower()!='application/json':raise ValueError('Expected JSON')
        n=self.headers.get('Content-Length','')
        if not n.isdigit() or int(n)>2048:raise ValueError('Invalid length')
        data=json.loads(self.rfile.read(int(n)))
        if not isinstance(data,dict):raise ValueError('Expected object')
        return data
    def route_get(self,head=False):
        if not self.context():self.send(400,b'Bad Host',mime='text/plain',head=head);return
        path=urlsplit(self.path).path
        if path=='/healthz':self.send(200,b'ok\n',mime='text/plain',head=head);return
        if path=='/api/setup-status':self.json(200,{'configured':auth_ready(),'mfa_required':True,'mfa_ready':mfa_ready()},head=head);return
        if path in ROUTES:
            name,mime=ROUTES[path];self.send(200,(ROOT/name).read_bytes(),mime=mime,head=head);return
        if path.startswith('/api/'):
            session=self.auth()
            if not session:self.json(401,{'error':'Требуется вход'},head=head);return
            if path=='/api/session':self.json(200,{'authenticated':True,'csrf':session[1]['csrf'],'expires_in':max(0,int(session[1]['expires']-time.monotonic()))},head=head);return
            if path=='/api/status':self.json(200,load_status(STATUS_FILE),head=head);return
            if path=='/api/projects':self.send(200,PROJECTS.read_bytes(),head=head);return
            if path.startswith('/api/actions/'):
                rid=path.rsplit('/',1)[-1]
                if not RID.fullmatch(rid):self.json(404,{'error':'Не найдено'},head=head);return
                result=safe_result(RESULTS_DIR/f'{rid}.json')
                self.json(200,result if result is not None else {'request_id':rid,'pending':True},head=head);return
        self.send(404,b'Not found',mime='text/plain',head=head)
    def do_GET(self):self.route_get(False)
    def do_HEAD(self):self.route_get(True)
    def do_POST(self):
        if not self.context():self.json(400,{'error':'Bad Host'});return
        path=urlsplit(self.path).path
        if path not in {'/api/login','/api/logout','/api/actions'}:self.json(405,{'error':'Недопустимый метод'});return
        if not self.origin_ok():self.json(403,{'error':'Недопустимый источник запроса'});return
        if path=='/api/login':
            if not auth_ready():self.json(503,{'error':'Пароль ещё не настроен на VDS. Используй tools/password.py через SSH.'});return
            otp_record=read_record(MFA_FILE)
            if otp_record is None:self.json(503,{'error':'Второй фактор не настроен на VDS. Используй tools/mfa_setup.py через SSH.'});return
            now=time.monotonic();ip=self.client_address[0]
            with LOCK:
                for address, stamps in list(FAILURES.items()):
                    fresh=[t for t in stamps if now-t<900]
                    if fresh:FAILURES[address]=fresh
                    else:FAILURES.pop(address,None)
                limited=(len(FAILURES)>=MAX_FAILURE_IPS and ip not in FAILURES) or len(FAILURES.get(ip,[]))>=5
            if limited:self.json(429,{'error':'Слишком много попыток. Повторите позже.'});return
            try:
                request=self.read_json()
                if set(request) not in ({'password','otp'},{'password'}):raise ValueError()
            except (ValueError,TypeError):self.json(400,{'error':'Неверный формат данных'});return
            if not check_password(request.get('password')) or check_otp(request.get('otp'),otp_record) is None:
                with LOCK:FAILURES.setdefault(ip,[]).append(time.monotonic())
                self.json(401,{'error':'Неверный пароль'});return
            token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(32)
            with LOCK:
                FAILURES.pop(ip,None)
                # Single-user bounded session table
                for key,s in list(SESSIONS.items()):
                    if now>s['expires'] or now-s['last']>SESSION_IDLE:SESSIONS.pop(key,None)
                if len(SESSIONS)>=32:SESSIONS.pop(next(iter(SESSIONS)))
                SESSIONS[hashlib.sha256(token.encode()).hexdigest()]={'csrf':csrf,'last':now,'expires':now+SESSION_ABSOLUTE}
            self.json(200,{'authenticated':True,'csrf':csrf},cookie='ph_session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=14400'+('; Secure' if self.headers.get('Origin','')=='https://'+TAILSCALE_HOST and TAILSCALE_HOST else ''));return
        session=self.auth()
        if not session:self.json(401,{'error':'Требуется вход'});return
        if not self.csrf_ok(session):self.json(403,{'error':'Неверная CSRF-защита'});return
        if path=='/api/logout':
            with LOCK:SESSIONS.pop(session[0],None)
            self.send(204,cookie='ph_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'+('; Secure' if self.headers.get('Origin','')=='https://'+TAILSCALE_HOST and TAILSCALE_HOST else ''));return
        try:
            request=self.read_json()
            if (set(request)!={'container_id','action'} or request.get('action') not in OPS or
                not isinstance(request.get('container_id'),str) or not CID.fullmatch(request['container_id'])):raise ValueError()
        except (ValueError,TypeError):self.json(400,{'error':'Недопустимая операция'});return
        now=time.monotonic()
        with LOCK:
            key=session[0]
            ACTION_COUNTS[key]=[t for t in ACTION_COUNTS.get(key,[]) if now-t<60]
            if len(ACTION_COUNTS[key])>=10:self.json(429,{'error':'Слишком много операций за минуту'});return
            ACTION_COUNTS[key].append(now)
        if not QUEUE_DIR.is_dir() or QUEUE_DIR.is_symlink():self.json(503,{'error':'Очередь недоступна'});return
        if len(list(QUEUE_DIR.glob('*.json')))>25:self.json(503,{'error':'Очередь заполнена'});return
        rid=secrets.token_hex(16)
        try:
            fd=os.open(QUEUE_DIR/f'{rid}.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
            with os.fdopen(fd,'w',encoding='utf-8') as f:
                json.dump(request,f);f.flush();os.fsync(f.fileno())
        except OSError:self.json(503,{'error':'Ошибка записи очереди'});return
        self.json(202,{'request_id':rid,'pending':True})
    def log_message(self,fmt,*args):
        # Never log URLs, cookies, password bodies or session IDs.
        print('http',self.client_address[0],args[1] if len(args)>1 else '-',flush=True)

class BoundedHTTPServer(ThreadingHTTPServer):
    # Public Funnel requests must not create unlimited worker threads or hang forever.
    request_queue_size=16
    daemon_threads=True
    max_workers=8
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self._available=threading.BoundedSemaphore(self.max_workers)

    def process_request(self, request, client_address):
        if not self._available.acquire(blocking=False):
            request.close()
            return
        try:
            request.settimeout(8)
            super().process_request(request,client_address)
        except Exception:
            self._available.release()
            raise

    def process_request_thread(self,request,client_address):
        try:
            super().process_request_thread(request,client_address)
        finally:
            self._available.release()


def main():
    httpd=BoundedHTTPServer(('0.0.0.0',int(os.environ.get('PORT','8765'))),Handler)
    httpd.daemon_threads=True
    try:httpd.serve_forever(poll_interval=.25)
    except KeyboardInterrupt:pass
    finally:httpd.server_close()
if __name__=='__main__':main()
