'use strict';
const $ = (id) => document.getElementById(id);
const views = {overview:'Обзор',containers:'Контейнеры',projects:'Проекты',system:'Система'};
const state = {status:null,projects:[],active:'overview',busy:false,csrf:'',initialized:false};
const nf = new Intl.NumberFormat('ru-RU',{maximumFractionDigits:1});
function show(view){
  if(!Object.hasOwn(views,view))return;
  state.active=view;
  for(const key of Object.keys(views))$('view-'+key).classList.toggle('hidden',key!==view);
  document.querySelectorAll('[data-view]').forEach(b=>{
    const selected=b.dataset.view===view;
    b.classList.toggle('active',selected);
    if(b.matches('.nav-item,.mobile-item')){if(selected)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');}
  });
  $('breadcrumb-current').textContent=views[view];
  window.scrollTo({top:0,behavior:'instant'});
}
function text(id,value){$(id).textContent=value;}
function bytes(n){if(!Number.isFinite(n)||n<0)return '—'; if(n>=1e12)return nf.format(n/1e12)+' ТБ';if(n>=1e9)return nf.format(n/1e9)+' ГБ';if(n>=1e6)return nf.format(n/1e6)+' МБ';if(n>=1e3)return nf.format(n/1e3)+' КБ';return nf.format(n)+' Б';}
function duration(n){if(!Number.isFinite(n)||n<0)return '—'; const d=Math.floor(n/86400),h=Math.floor((n%86400)/3600),m=Math.floor((n%3600)/60);return (d?d+' дн. ':'')+(h?h+' ч. ':'')+m+' мин.';}
function node(tag,klass,txt){const e=document.createElement(tag);if(klass)e.className=klass;if(txt!==undefined)e.textContent=String(txt);return e;}
function empty(target,message){target.replaceChildren(node('p','empty-message',message));}
function meter(prefix,number){const n=Number.isFinite(number)?Math.max(0,Math.min(100,number)):null;text(prefix+'-value',n===null?'—':nf.format(n));const fill=$(prefix+'-meter');fill.style.width=(n??0)+'%';fill.classList.toggle('high',n!==null&&n>=85);}
function updateContainers(d){const docker=d?.docker;const list=$('container-list'),preview=$('docker-preview');
  if(!docker?.available){empty(list,'Docker недоступен. Проверь журнал сборщика.');empty(preview,'Нет данных Docker');text('container-summary','Нет данных');text('docker-total','—');text('docker-running','—');text('side-count','—');return;}
  const cs=Array.isArray(docker.containers)?docker.containers:[];
  const running=cs.filter(c=>c.state==='running').length;
  text('container-summary',`Всего: ${docker.total} · Работают: ${running}${docker.truncated?' · Список сокращён':''}`);
  text('docker-total',docker.total);text('docker-running',running);text('side-count',docker.total);
  const previewItems=cs.slice(0,3).map(c=>{const row=node('div','mini-row');row.append(node('strong','',c.name),node('span',c.state==='running'?'okay':'',c.state==='running'?'Работает':c.state));return row;});
  if(previewItems.length)preview.replaceChildren(...previewItems);else empty(preview,'Контейнеров нет — Docker чист.');
  const term=$('container-search').value.trim().toLocaleLowerCase();
  const filtered=cs.filter(c=>(c.name+' '+c.image).toLocaleLowerCase().includes(term));
  if(!filtered.length){empty(list,term?'Ничего не найдено.':'Контейнеров пока нет.');return;}
  list.replaceChildren(...filtered.map(c=>{const row=node('article','container-row');
    const main=node('div','container-meta');main.append(node('div','container-name',c.name),node('div','container-image',c.image));
    const info=node('div','state-col');info.append(node('div','state-label '+(c.state||''),c.state==='running'?'Работает':(c.state||'Неизвестно')),node('div','container-detail',c.status));
    row.append(main,info);
    const controls=node('div','container-controls');
    if(c.managed && c.id){
      const options=[['logs','Логи'],[c.state==='running'?'restart':'start',c.state==='running'?'Перезапустить':'Запустить']];
      if(c.state==='running')options.push(['stop','Остановить']);
      for(const [action,label] of options){const b=node('button','action-button '+(action==='stop'?'danger-action':''),label);b.type='button';b.addEventListener('click',()=>runAction(c,action));controls.append(b);}
    } else controls.append(node('span','access-note',c.project?'Управление не разрешено':'Нет разрешённого Compose-проекта'));
    row.append(controls);return row;}));
}
function updateProjects(){const list=$('projects-list'),preview=$('project-preview');
  if(!state.projects.length){empty(list,'Репозитории пока не настроены.');empty(preview,'Нет репозиториев');return;}
  list.replaceChildren(...state.projects.map(p=>{
    const a=node('a','project-card');a.href=p.repo;a.target='_blank';a.rel='noopener noreferrer';
    const initial=node('span','project-initial',p.name.slice(0,1));const labels=node('span','project-text');labels.append(node('strong','',p.name),node('small','',p.type));
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');const use=document.createElementNS('http://www.w3.org/2000/svg','use');use.setAttribute('href','#i-external');svg.append(use);a.append(initial,labels,svg);return a;
  }));
  preview.replaceChildren(...state.projects.slice(0,3).map(p=>{const r=node('div','mini-row');r.append(node('strong','',p.name),node('span','',p.type.split(' · ')[0]));return r;}));
}
function updateStatus(s){state.status=s;
  const ok=s.ok&&!s.stale, d=s.data;
  $('alert').classList.toggle('hidden',ok);
  if(!ok)text('alert',s.ok?'Данные устарели. Проверь таймер сбора статуса.':(s.error||'Нет данных VDS.'));
  $('pulse').classList.toggle('live',ok);
  $('hero-health').className='health-tag'+(ok?' healthy':' warn');
  text('hero-health',ok?'Мониторинг активен':'Нет свежих данных');
  text('last-sync',s.ok?`Обновлено ${s.age_seconds} сек. назад`:'Нет данных');
  if(!d){for(const p of ['cpu','ram','disk']){meter(p,null);text(p+'-detail','Нет данных');}
    updateContainers(null);for(const k of ['system-collector','system-time','system-uptime','system-docker'])text(k,'—');return;}
  meter('cpu',d.cpu_percent);meter('ram',d.memory?.percent);meter('disk',d.disk?.percent);
  text('cpu-detail',d.cpu_percent===null?'Собирается первый интервал':'Нагрузка всех ядер');
  text('ram-detail',`${bytes(d.memory?.used_bytes)} из ${bytes(d.memory?.total_bytes)}`);
  text('disk-detail',`${bytes(d.disk?.available_bytes)} свободно из ${bytes(d.disk?.total_bytes)}`);
  text('system-collector',ok?'Работает':'Данные устарели');
  text('system-time',new Date(d.collected_at).toLocaleString('ru-RU'));
  text('system-uptime',duration(d.uptime_seconds));
  text('system-docker',d.docker?.available?'Доступен':'Недоступен');
  updateContainers(d);
}
async function refresh(){if(state.busy)return;state.busy=true;const btn=$('refresh');btn.disabled=true;btn.classList.add('loading');try{
  const r=await fetch('/api/status',{cache:'no-store'});if(r.status===401){locked();return;}if(!r.ok)throw new Error('HTTP '+r.status);updateStatus(await r.json());
}catch(e){updateStatus({ok:false,stale:true,error:'Не удалось получить статус. Проверь приватное соединение и контейнер Project Hub.'});}
finally{state.busy=false;btn.disabled=false;btn.classList.remove('loading');}}
async function setup(){if(state.initialized)return;state.initialized=true;document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>show(b.dataset.view)));
  $('refresh').addEventListener('click',refresh);$('container-search').addEventListener('input',()=>{if(state.status?.data)updateContainers(state.status.data);});
  $('copy-tunnel').addEventListener('click',async()=>{const cmd='ssh -i "$HOME/.ssh/wr-community" -L 8765:127.0.0.1:8765 root@139.100.205.135';try{await navigator.clipboard.writeText(cmd);text('copy-tunnel','Скопировано');}catch{ text('copy-tunnel','Выдели команду');}});
  try{const r=await fetch('/api/projects');if(!r.ok)throw Error('project request failed');const p=await r.json();state.projects=Array.isArray(p)?p.filter(x=>x.name&&/^https:\/\/github\.com\//.test(x.repo)):[];}catch{state.projects=[];}
  updateProjects();await refresh();setInterval(()=>{if(document.visibilityState==='visible')refresh();},30000);
}
async function apiPost(path,obj){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':state.csrf},credentials:'same-origin',body:JSON.stringify(obj)});if(r.status===401){locked();throw Error('Требуется повторный вход');}if(!r.ok){const data=await r.json().catch(()=>({}));throw Error(data.error||('HTTP '+r.status));}return r.status===204?{}:r.json();}
function toast(message,failed=false){const e=$('action-toast');e.textContent=message;e.className='action-toast'+(failed?' toast-error':'');e.classList.remove('hidden');setTimeout(()=>e.classList.add('hidden'),6000);}
async function runAction(c,action){
  if(!state.csrf)return;
  if(action==='stop'&&!confirm(`Остановить ${c.name}? Работа сервиса будет прервана.`))return;
  if(action==='restart'&&!confirm(`Перезапустить ${c.name}? Возможен краткий перерыв в работе.`))return;
  const dialog=$('log-dialog');
  if(action==='logs'){$('log-title').textContent='Логи: '+c.name;$('log-output').textContent='Запрашиваем логи…';dialog.showModal();}
  toast('Команда '+action+' поставлена в очередь…');
  try{const {request_id:id}=await apiPost('/api/actions',{container_id:c.id,action});
    for(let i=0;i<24;i++){
      await new Promise(resolve=>setTimeout(resolve,1300));
      const resp=await fetch('/api/actions/'+id,{cache:'no-store'});
      if(!resp.ok)throw Error('Не удалось прочитать результат');
      const result=await resp.json();if(result.pending)continue;
      if(action==='logs')$('log-output').textContent=result.output||result.message||'Лог пуст';
      toast(result.message||'Операция завершена',!result.ok);
      await refresh();return;
    }
    toast('Операция обрабатывается. Проверь её статус позже.',true);
    if(action==='logs')$('log-output').textContent='Ответ от обработчика не получен. Проверь systemd worker.';
  }catch(e){toast(e.message,true);if(action==='logs')$('log-output').textContent=e.message;}
}
function locked(message='Войдите для доступа к инфраструктуре.'){
  state.csrf='';document.body.classList.remove('signed-in');document.body.classList.add('auth-check');
  $('login-error').textContent=message;
}
async function boot(){
  $('login-form').addEventListener('submit',async(e)=>{
    e.preventDefault();const btn=$('login-button');btn.disabled=true;$('login-error').textContent='';
    try{const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({password:$('login-password').value,otp:$('login-otp').value})});
      const result=await r.json();if(!r.ok)throw Error(result.error||'Неверный пароль');
      state.csrf=result.csrf;$('login-password').value='';$('login-otp').value='';document.body.classList.add('signed-in');document.body.classList.remove('auth-check');await setup();await refresh();
    }catch(err){$('login-error').textContent=err.message;$('login-otp').value='';}finally{btn.disabled=false;}
  });
  $('toggle-password').addEventListener('click',()=>{const field=$('login-password');field.type=field.type==='password'?'text':'password';$('toggle-password').textContent=field.type==='password'?'Показать':'Скрыть';});
  $('logout').addEventListener('click',async()=>{try{await apiPost('/api/logout',{});}catch{}locked('Сессия завершена.');});
  $('close-log').addEventListener('click',()=>$('log-dialog').close());
  try{const r=await fetch('/api/session',{cache:'no-store'});if(!r.ok)throw Error('');const data=await r.json();state.csrf=data.csrf;document.body.classList.add('signed-in');document.body.classList.remove('auth-check');await setup();}catch{locked('Введите пароль администратора.');}
  try{const r=await fetch('/api/setup-status',{cache:'no-store'});if(r.ok){const setup=await r.json();if(!setup.configured)$('login-error').textContent='Пароль ещё не настроен. Создай его через root SSH.';else if(!setup.mfa_ready)$('login-error').textContent='Второй фактор не настроен. Настрой его через root SSH командой python3 /opt/project-hub/tools/mfa_setup.py';}}catch{}
}
boot();
