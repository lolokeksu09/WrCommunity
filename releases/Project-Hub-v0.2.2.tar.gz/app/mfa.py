"""Minimal RFC 6238 TOTP verification (SHA-1, 6 digits, 30 seconds), no dependencies."""
from __future__ import annotations
import base64
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import stat
import struct
import time

CONFIG_FIELDS = {'version', 'algorithm', 'digits', 'period', 'secret'}
SECRET_RE = re.compile(r'[A-Z2-7]{32}')
CODE_RE = re.compile(r'[0-9]{6}')


def parse_record(record):
    if not isinstance(record, dict) or set(record) != CONFIG_FIELDS:
        return None
    if (record['version'], record['algorithm'], record['digits'], record['period']) != (1, 'totp-sha1', 6, 30):
        return None
    encoded = record['secret']
    if not isinstance(encoded, str) or not SECRET_RE.fullmatch(encoded):
        return None
    try:
        secret = base64.b32decode(encoded, casefold=False)
    except (ValueError, base64.binascii.Error):
        return None
    return secret if len(secret) == 20 else None


def read_record(path: Path):
    """Return a validated record only when a regular no-follow file is present."""
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
        with os.fdopen(fd, 'rb') as f:
            entry = os.fstat(f.fileno())
            if not stat.S_ISREG(entry.st_mode) or entry.st_size > 512 or entry.st_nlink != 1:
                return None
            raw = f.read(513)
        if len(raw) > 512:
            return None
        record = json.loads(raw)
        return record if parse_record(record) is not None else None
    except (OSError, ValueError, TypeError):
        return None


def totp_code(secret: bytes, when=None) -> str:
    when = time.time() if when is None else when
    counter = int(when) // 30
    digest = hmac.new(secret, struct.pack('>Q', counter), hashlib.sha1).digest()
    pos = digest[-1] & 0xf
    number = (struct.unpack('>I', digest[pos:pos + 4])[0] & 0x7fffffff) % 1000000
    return f'{number:06d}'


def check_otp(code, record, when=None):
    """Accept current 30-second time step or adjacent one for clock skew."""
    if not isinstance(code, str) or not CODE_RE.fullmatch(code):
        return None
    secret = parse_record(record)
    if secret is None:
        return None
    now = time.time() if when is None else when
    for offset in (-30, 0, 30):
        t = now + offset
        if t >= 0 and hmac.compare_digest(totp_code(secret, t), code):
            return int(t) // 30
    return None
