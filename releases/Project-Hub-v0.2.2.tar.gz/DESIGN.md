# Project Hub v0.2.2 — security-first mobile login

The visual design remains the v0.2.1 AMOLED layout; added a clearly labeled 6-digit OTP input under the existing password field. Both fields are required. Chrome uses the numeric keypad for OTP. Public Funnel text is accurately labeled as internet-exposed HTTPS protected by password and TOTP, not a private Tailscale-only link.

The dashboard layout, mobile bottom navigation and 390/1440 responsive rules are unchanged; security fixes are intentionally scoped to authentication, HTTP concurrency, and security copy.

# Project Hub v0.2.0 — UX и система доступа

- **Назначение:** приватная личная админ-панель для работы с VDS и Docker; mobile-first / Operate.
- **Вход:** отдельная страница с ясным брендингом, полем пароля и состояниями ошибки, блокировки и отсутствующей настройки. Никакого пароля по умолчанию.
- **Сессия:** защищённая server-side запись; нет токенов в localStorage или URL; выход отзывает сессию.
- **Основная панель:** сохраняет структуру v0.1 (Обзор / Docker / Проекты / Система), реальные цифры, статус обновления и AMOLED. В хедере ADMIN и Выход.
- **Контейнеры:** название, образ, состояние, фиксированные действия. У каждого неразрешённого проекта — явная подпись почему кнопок нет. Для Stop и Restart обязательное подтверждение последствия. Логи читаются в dialog со скроллом, а не выводятся в HTML через innerHTML.
- **Операции:** состояния очередь/успех/ошибка/долгая операция; обработчик host-side whitelist. Не вводить псевдотерминал и не делать Docker socket доступным веб-контейнеру.
- **Адаптивность:** 390px/1440px, большой контраст, крупные touch targets, ясные focus состояния, снижение анимаций при reduced-motion. Визуальная браузерная проверка должна быть выполнена на VDS/браузере: локальный Chromium заблокирован системной политикой.
