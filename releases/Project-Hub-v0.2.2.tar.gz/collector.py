#!/usr/bin/env python3
"""Read-only host metrics snapshot for Project Hub. Run via root-owned systemd timer."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess

MAX_DOCKER_ROWS = 100
MANAGED_PROJECTS = Path('/opt/project-hub/private/managed-projects.json')

def managed_projects():
    try:
        if MANAGED_PROJECTS.is_symlink(): return set()
        with MANAGED_PROJECTS.open('rb') as f: raw=f.read(4097)
        if len(raw)>4096:return set()
        allowed=json.loads(raw)
        return set(x for x in allowed if isinstance(x,str)) if isinstance(allowed,list) else set()
    except (OSError,ValueError,TypeError):return set()



def cpu_sample(proc: Path = Path('/proc')) -> tuple[int, int]:
    line = (proc / 'stat').read_text(encoding='ascii').splitlines()[0].split()
    if line[0] != 'cpu' or len(line) < 8:
        raise ValueError('Unexpected /proc/stat format')
    values = [int(n) for n in line[1:]]
    idle = values[3] + values[4]
    total = sum(values)
    return idle, total


def memory(proc: Path = Path('/proc')) -> dict:
    raw = {}
    for line in (proc / 'meminfo').read_text(encoding='ascii').splitlines():
        if ':' in line:
            name, value = line.split(':', 1)
            parts = value.strip().split()
            if parts and parts[0].isdigit():
                raw[name] = int(parts[0]) * 1024  # Linux meminfo kB
    total = raw['MemTotal']
    available = min(total, raw['MemAvailable'])
    return {'total_bytes': total, 'used_bytes': total - available, 'percent': round(100 * (total - available) / total, 1)}


def disk(path: str = '/') -> dict:
    s = os.statvfs(path)
    total, available = s.f_blocks * s.f_frsize, s.f_bavail * s.f_frsize
    used = (s.f_blocks - s.f_bfree) * s.f_frsize
    return {'total_bytes': total, 'available_bytes': available, 'used_bytes': used,
            'percent': round(100 * used / (used + available), 1) if used + available else 0}


def uptime_seconds(proc: Path = Path('/proc')) -> int:
    return int(float((proc / 'uptime').read_text(encoding='ascii').split()[0]))


def docker_state() -> dict:
    try:
        cp = subprocess.run(['docker', 'ps', '-a', '--format', '{{json .}}'],
                            check=True, text=True, capture_output=True, timeout=8)
        rows = [json.loads(line) for line in cp.stdout.splitlines() if line.strip()]
        containers = []
        allow = managed_projects()
        for row in rows[:MAX_DOCKER_ROWS]:
            item={k: str(row.get(field, ''))[:180] for k, field in
                  [('name', 'Names'), ('image', 'Image'), ('state', 'State'), ('status', 'Status')]}
            identifier=str(row.get('ID',''))
            labels=str(row.get('Labels',''))
            # Docker ps JSON labels can be map or CSV; display is informative only.
            project=next((label.split('=',1)[1] for label in labels.split(',') if label.startswith('com.docker.compose.project=')), '')
            if isinstance(row.get('Labels'),dict):project=row['Labels'].get('com.docker.compose.project','')
            item.update({'id':identifier if len(identifier) in (12,64) and all(c in '0123456789abcdef' for c in identifier) else '',
                         'project':project[:64],'managed':project in allow and project!='project-hub'})
            containers.append(item)
        return {'available': True, 'total': len(rows), 'truncated': len(rows) > MAX_DOCKER_ROWS,
                'containers': containers}
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired, ValueError, TypeError):
        return {'available': False, 'total': None, 'truncated': False, 'containers': [],
                'error': 'Docker status unavailable; check collector journal'}


def snapshot(previous: dict | None = None, proc: Path = Path('/proc'), disk_path: str = '/') -> dict:
    idle, total = cpu_sample(proc)
    cpu = None
    if previous and isinstance(previous.get('_cpu_sample'), list) and len(previous['_cpu_sample']) == 2:
        prev_idle, prev_total = previous['_cpu_sample']
        delta = total - prev_total
        if isinstance(prev_idle, int) and isinstance(prev_total, int) and delta > 0:
            cpu = round(max(0.0, min(100.0, 100 * (1 - (idle - prev_idle) / delta))), 1)
    return {'schema_version': 1, 'collected_at': datetime.now(timezone.utc).isoformat(),
            'cpu_percent': cpu, '_cpu_sample': [idle, total], 'memory': memory(proc),
            'disk': disk(disk_path), 'uptime_seconds': uptime_seconds(proc),
            'docker': docker_state()}


def atomic_write_json(path: Path, data: dict) -> None:
    # state/ must be owned by the operator; do not follow symlinked destination directories.
    if path.parent.is_symlink() or not path.parent.is_dir():
        raise RuntimeError('Status parent is not a real directory')
    if path.is_symlink():
        raise RuntimeError('Status destination must not be a symlink')
    tmp = path.with_name(f'.{path.name}.{os.getpid()}.tmp')
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(tmp, flags, 0o644)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(data, handle, sort_keys=True, ensure_ascii=False)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    previous = None
    try:
        previous = json.loads(args.output.read_text(encoding='utf-8'))
    except (FileNotFoundError, json.JSONDecodeError, PermissionError):
        pass
    data = snapshot(previous)
    atomic_write_json(args.output, data)
    print('Project Hub snapshot saved; no Docker actions performed')


if __name__ == '__main__':
    main()
