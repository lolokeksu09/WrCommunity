#!/usr/bin/env bash
set -Eeuo pipefail
cd /opt/project-hub
printf '=== Project Hub v0.2: service ===\n'
docker compose config -q
docker compose ps
printf '=== Systemd timers ===\n'
systemctl is-active project-hub-collector.timer project-hub-worker.timer
printf '=== HTTP health ===\n'
curl -fsS -m 5 http://127.0.0.1:8765/healthz
printf '\n=== Auth gate (should be HTTP 401 before login) ===\n'
status=$(curl -sS -o /dev/null -w '%{http_code}' -m 5 http://127.0.0.1:8765/api/session)
printf '%s\n' "$status"
test "$status" = 401
printf '=== Password setup status ===\n'
curl -fsS -m 5 http://127.0.0.1:8765/api/setup-status
printf '\nPASS: loopback health and auth gate. Browser and Docker actions require separate checks.\n'
