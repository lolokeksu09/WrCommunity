#!/usr/bin/env bash
# One-time private HTTPS access: no Funnel, public 8765 remains closed.
set -Eeuo pipefail
[[ ${EUID:-9999} -eq 0 ]] || { echo 'Run on VDS as root' >&2; exit 1; }
cd /opt/project-hub
curl -fsS --max-time 5 http://127.0.0.1:8765/healthz >/dev/null || { echo 'Project Hub is not healthy on localhost:8765' >&2; exit 1; }
if ! command -v tailscale >/dev/null; then
  echo 'Tailscale not installed. Install from https://tailscale.com/docs/install/linux and rerun.' >&2
  exit 1
fi
systemctl is-active --quiet tailscaled || { echo 'tailscaled is not running' >&2; exit 1; }
python3 - <<'PYINNER'
import json,subprocess,sys
p=subprocess.run(['tailscale','status','--json'],capture_output=True,text=True)
if p.returncode:sys.exit('Tailscale is not logged in: run tailscale up first')
status=json.loads(p.stdout)
if status.get('BackendState')!='Running':sys.exit('Tailscale is not logged in: run tailscale up first')
dns=status.get('Self',{}).get('DNSName','').rstrip('.').lower()
import re
if not re.fullmatch(r'[a-z0-9][a-z0-9.-]{0,240}\.ts\.net',dns):sys.exit('Missing trusted .ts.net DNSName; configure MagicDNS/HTTPS')
with open('/opt/project-hub/.env','w') as f:f.write('PH_TAILSCALE_HOST='+dns+'\n')
print('Configured trusted host:',dns)
PYINNER
chmod 600 /opt/project-hub/.env
docker compose up -d --no-deps web
# This is tailnet-only, NOT the public tailscale funnel command.
tailscale serve --bg --https=443 http://127.0.0.1:8765
printf '\n=== PRIVATE ADDRESS ===\n'
tailscale serve status
printf '\nThis URL is usable on devices logged into the same Tailscale network.\n'
