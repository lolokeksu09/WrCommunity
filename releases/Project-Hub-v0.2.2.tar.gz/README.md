# Project Hub v0.2.2 — пароль + одноразовый код

Security update for the installed v0.2.1 mobile admin panel. All old monitoring, project links, and bounded Docker actions remain; the current `private/auth.json`, `.env`, status, queue and allowlist are **not** packaged and are preserved.

## Why v0.2.2?

The user-enabled Tailscale **Funnel** provides a publicly accessible HTTPS login page, not a private tailnet. This release requires **two-factor authentication (TOTP)** for every login: current password + 6-digit authenticator code. It also enforces a bounded number of HTTP workers, shortens session lifetime, and strengthens security response headers. No Cloudflare account, domain, or phone VPN is needed. The address remains the existing Funnel `.ts.net` address.

## Install/update from Termux (existing VDS)

The archive must be downloaded to Android's `Download` folder. Android sometimes saves `*.tar.gz` as `*.tar.gz.tar`. The command below supports both filenames. It **does not delete** application state, Docker volumes, other projects, password, or SSH configuration.

**Prepare an authenticator app first** (2FAS, Aegis, Google Authenticator or equivalent). The one-time setup will show a secret key **only in Termux**, and ask you to enter the 6-digit code to confirm it. Do not send or screenshot the secret in chat.

```bash
archive=""
for f in /storage/emulated/0/Download/Project-Hub-v0.2.2.tar.gz /storage/emulated/0/Download/Project-Hub-v0.2.2.tar.gz.tar; do
  if [ -f "$f" ]; then archive="$f"; break; fi
done
if [ -z "$archive" ]; then echo 'Сначала скачай TAR.GZ в Download'; else
  if tar -tzf "$archive" >/dev/null 2>&1; then
    ssh -i "$HOME/.ssh/wr-community" -o IdentitiesOnly=yes root@139.100.205.135 \
      'install -d -m 0755 /opt/project-hub && tar -xzf - -C /opt/project-hub && cd /opt/project-hub && sha256sum --check --status SHA256SUMS.txt' \
      < "$archive" && \
    ssh -tt -i "$HOME/.ssh/wr-community" -o IdentitiesOnly=yes root@139.100.205.135 \
      'cd /opt/project-hub && if [ ! -s private/totp.json ]; then python3 tools/mfa_setup.py || exit 1; fi; bash install.sh'
  else
    echo 'Ошибка: архив не является действительным TAR.GZ'
  fi
fi
```

**Safe transition:** if TOTP enrollment fails or is missing, `install.sh` refuses to replace the currently running image; no login lockout is caused by a half-deployed v0.2.2. Existing admin password stays unchanged. The Docker Compose web container is recreated on successful update, revoking prior sessions.

## Use

Open the same public HTTPS address (the Funnel must still be configured on the VDS). Log in with your existing admin password **and** the new 6-digit code. Funnel works through Vitrum on Android and requires no Tailscale Android client.

## VDS checks

```bash
cd /opt/project-hub
sudo docker compose ps
curl -fsS http://127.0.0.1:8765/healthz
sudo systemctl status project-hub-collector.timer project-hub-worker.timer --no-pager
```

Only root SSH has access to the TOTP enrollment procedure, the credentials and the server service configuration. Never paste `private/auth.json`, `private/totp.json` or SSH keys in chat.

## Security and remaining risks

See `SECURITY.md`. Funnel exposes the login to the internet; TOTP prevents password-only account access, but it does not provide an external identity-aware access gateway or guarantee resistance to public DDoS. Existing worker queue isolation and the allowlisted Compose-project restriction are retained. Brute-force limiting remains in-memory and can temporarily lock out the admin behind shared Funnel IPs. Docker builds and live browser validation must be checked on the actual VDS.

## Local test commands

```bash
python3 -m unittest discover -s tests -v
python3 -m py_compile app/server.py app/mfa.py tools/mfa_setup.py tools/password.py tools/worker.py collector.py
node --check app/app.js
bash -n install.sh scripts/setup-tailscale.sh
sha256sum -c SHA256SUMS.txt
```
