"""Unit/integration tests; require Python stdlib only, not Docker."""
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from datetime import datetime, timezone, timedelta

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'app'))
import collector
import server


class CollectorTests(unittest.TestCase):
    def make_proc(self, path, stat):
        (path / 'stat').write_text(stat)
        (path / 'meminfo').write_text('MemTotal: 2048000 kB\nMemAvailable: 1024000 kB\n')
        (path / 'uptime').write_text('95020.42 12345.67\n')

    def test_cpu_deltas_and_memory(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc = Path(tmp)
            self.make_proc(proc, 'cpu  200 0 100 700 0 0 0 0 0\n')
            self.assertEqual(collector.cpu_sample(proc), (700, 1000))
            self.assertEqual(collector.memory(proc)['percent'], 50.0)
            self.assertEqual(collector.uptime_seconds(proc), 95020)
            with patch.object(collector, 'docker_state', return_value={'available': True, 'total': 0, 'containers': []}), \
                 patch.object(collector, 'disk', return_value={'total_bytes': 500, 'available_bytes': 200, 'used_bytes': 300, 'percent': 60.0}):
                first = collector.snapshot(proc=proc)
                self.assertIsNone(first['cpu_percent'])
                self.make_proc(proc, 'cpu  240 0 120 740 0 0 0 0 0\n')
                second = collector.snapshot(previous=first, proc=proc)
                self.assertEqual(second['cpu_percent'], 60.0)

    def test_docker_does_not_inspect_env_or_modify_containers(self):
        fake = subprocess.CompletedProcess([], 0, '{"Names":"hub","Image":"project-hub:0.1.0","State":"running","Status":"Up 1 minute"}\n', '')
        with patch.object(collector.subprocess, 'run', return_value=fake) as run:
            result = collector.docker_state()
            self.assertEqual(result['total'], 1)
            self.assertEqual(result['containers'][0]['name'], 'hub')
            self.assertEqual(run.call_args.args[0], ['docker', 'ps', '-a', '--format', '{{json .}}'])
            self.assertEqual(run.call_args.kwargs['timeout'], 8)

    def test_collector_marks_only_allowlisted_compose_containers(self):
        row={'Names':'demo-1','Image':'demo:latest','State':'running','Status':'Up','ID':'a'*12,'Labels':'com.docker.compose.project=demo,other=true'}
        fake=subprocess.CompletedProcess([],0,json.dumps(row)+'\n','')
        with patch.object(collector.subprocess,'run',return_value=fake),patch.object(collector,'managed_projects',return_value={'demo'}):
            container=collector.docker_state()['containers'][0]
            self.assertTrue(container['managed'])
            self.assertEqual(container['id'],'a'*12)
            self.assertEqual(container['project'],'demo')
        with patch.object(collector.subprocess,'run',return_value=fake),patch.object(collector,'managed_projects',return_value=set()):
            self.assertFalse(collector.docker_state()['containers'][0]['managed'])

    def test_docker_fails_closed(self):
        with patch.object(collector.subprocess, 'run', side_effect=subprocess.TimeoutExpired('docker', 8)):
            self.assertFalse(collector.docker_state()['available'])

    def test_atomic_write_and_symlink_refusal(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'status.json'
            collector.atomic_write_json(target, {'schema_version': 1})
            self.assertEqual(json.loads(target.read_text()), {'schema_version': 1})
            self.assertEqual(list(Path(tmp).glob('*.tmp')), [])
            target.unlink()
            target.symlink_to(Path(tmp) / 'not-allowed')
            with self.assertRaises(RuntimeError):
                collector.atomic_write_json(target, {'schema_version': 1})


class WebTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.httpd.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join(timeout=3)

    def get(self, path, *, method='GET', host=None):
        headers = {'Host': host} if host else {}
        req = Request(self.base + path, headers=headers, method=method)
        try:
            with urlopen(req, timeout=3) as response:
                return response.status, dict(response.headers), response.read()
        except HTTPError as err:
            return err.code, dict(err.headers), err.read()

    def test_static_and_health_and_content_security(self):
        for path in ('/', '/app.js', '/app.css', '/favicon.svg', '/healthz'):
            status, headers, content = self.get(path)
            self.assertEqual(status, 200, path)
            self.assertGreater(len(content), 0)
            self.assertIn("default-src 'none'", headers['Content-Security-Policy'])
            self.assertEqual(headers['X-Frame-Options'], 'DENY')
        status, _, body = self.get('/api/projects')
        self.assertEqual(status, 401)
        self.assertEqual(json.loads(body)['error'], 'Требуется вход')

    def test_no_mutating_routes_or_unlisted_files(self):
        self.assertEqual(self.get('/api/status', method='POST')[0], 405)
        self.assertEqual(self.get('/../../collector.py')[0], 404)
        self.assertEqual(self.get('/server.py')[0], 404)
        self.assertEqual(self.get('/does-not-exist')[0], 404)
        self.assertEqual(self.get('/',host='evil.example')[0], 400)

    def test_status_rejects_missing_large_stale_and_invalid(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'status.json'
            self.assertFalse(server.load_status(path)['ok'])
            path.write_bytes(b'x' * (server.MAX_STATUS_BYTES + 1))
            self.assertFalse(server.load_status(path)['ok'])
            valid = {'schema_version': 1, 'collected_at': datetime.now(timezone.utc).isoformat(),
                     '_cpu_sample': [10, 20], 'docker': {'available': True, 'containers': []}}
            path.write_text(json.dumps(valid))
            result = server.load_status(path)
            self.assertTrue(result['ok'])
            self.assertFalse(result['stale'])
            self.assertNotIn('_cpu_sample', result['data'])
            valid['collected_at'] = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
            path.write_text(json.dumps(valid))
            self.assertTrue(server.load_status(path)['stale'])
            valid['schema_version'] = 999
            path.write_text(json.dumps(valid))
            self.assertFalse(server.load_status(path)['ok'])

    def test_api_unconfigured_returns_explicit_error(self):
        with patch.object(server, 'STATUS_FILE', Path('/unavailable-project-hub-status.json')):
            status, _, payload = self.get('/api/status')
        self.assertEqual(status, 401)
        self.assertEqual(json.loads(payload)['error'], 'Требуется вход')


if __name__ == '__main__':
    unittest.main(verbosity=2)
