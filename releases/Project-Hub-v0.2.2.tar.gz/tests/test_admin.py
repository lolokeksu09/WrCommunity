"""Regression guards for login, authorization and bounded Docker command surface."""
from __future__ import annotations
import base64, importlib.util, json, sys, tempfile, threading, time, unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'app'))
def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
server=load('hub_server_admin', ROOT/'app/server.py')
worker=load('hub_worker_admin', ROOT/'tools/worker.py')
passwords=load('hub_passwords_admin', ROOT/'tools/password.py')
mfa=load('hub_mfa_admin', ROOT/'app/mfa.py')

class SecurityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        cls.path=Path(cls.tmp.name)
        (cls.path/'queue').mkdir()
        (cls.path/'results').mkdir()
        cls.auth=cls.path/'auth.json'
        cls.auth.write_text(json.dumps(passwords.make_password_record('long-test-password-123')))
        cls.mfa=cls.path/'mfa.json'
        cls.mfa.write_text(json.dumps({'version':1,'algorithm':'totp-sha1','digits':6,'period':30,'secret':base64.b32encode(b'12345678901234567890').decode().rstrip('=')}))
        cls.patchers=[patch.object(server,'AUTH_FILE',cls.auth),patch.object(server,'MFA_FILE',cls.mfa), patch.object(server,'QUEUE_DIR',cls.path/'queue'),patch.object(server,'RESULTS_DIR',cls.path/'results')]
        for p in cls.patchers: p.start()
        cls.httpd=ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        cls.thread=threading.Thread(target=cls.httpd.serve_forever,daemon=True)
        cls.thread.start();cls.url=f'http://127.0.0.1:{cls.httpd.server_port}'
    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown();cls.httpd.server_close();cls.thread.join(timeout=2)
        for p in reversed(cls.patchers):p.stop()
        cls.tmp.cleanup()
    def setUp(self):
        with server.LOCK:
            server.FAILURES.clear()

    def call(self,method,path,payload=None,cookie='',csrf='',origin=None):
        headers={'Host':f'127.0.0.1:{self.httpd.server_port}'}
        if cookie:headers['Cookie']=cookie
        if csrf:headers['X-CSRF-Token']=csrf
        if origin is not None: headers['Origin']=origin
        if payload is not None:headers['Content-Type']='application/json'
        data=json.dumps(payload).encode() if payload is not None else None
        req=Request(self.url+path,data=data,headers=headers,method=method)
        try:
            with urlopen(req,timeout=3) as r:return r.status,dict(r.headers),r.read()
        except HTTPError as e:return e.code,dict(e.headers),e.read()
    def login(self):
        code, headers, body=self.call('POST','/api/login',{'password':'long-test-password-123','otp':mfa.totp_code(b'12345678901234567890')},origin=self.url)
        self.assertEqual(code,200,body)
        return headers['Set-Cookie'].split(';')[0],json.loads(body)['csrf']
    def test_password_protection_and_logout(self):
        self.assertEqual(self.call('GET','/api/status')[0],401)
        self.assertEqual(self.call('GET','/api/projects')[0],401)
        self.assertEqual(self.call('POST','/api/login',{'password':'bad'},origin=self.url)[0],401)
        self.assertEqual(self.call('POST','/api/login',{'password':'long-test-password-123'},origin='http://evil.test')[0],403)
        cookie,csrf=self.login()
        self.assertEqual(self.call('GET','/api/session',cookie=cookie)[0],200)
        self.assertEqual(self.call('POST','/api/logout',{},cookie=cookie,origin=self.url)[0],403)
        self.assertEqual(self.call('POST','/api/logout',{},cookie=cookie,csrf=csrf,origin=self.url)[0],204)
        self.assertEqual(self.call('GET','/api/session',cookie=cookie)[0],401)
    def test_mutations_fail_closed(self):
        cookie,csrf=self.login()
        cid='a'*12
        p={'action':'restart','container_id':cid}
        self.assertEqual(self.call('POST','/api/actions',p,cookie=cookie,csrf=csrf)[0],403)
        self.assertEqual(self.call('POST','/api/actions',p,cookie=cookie,origin=self.url)[0],403)
        self.assertEqual(self.call('POST','/api/actions',{'action':'rm','container_id':cid},cookie=cookie,csrf=csrf,origin=self.url)[0],400)
        self.assertEqual(self.call('POST','/api/actions',{'action':'restart','container_id':'../'},cookie=cookie,csrf=csrf,origin=self.url)[0],400)
        code,_,body=self.call('POST','/api/actions',p,cookie=cookie,csrf=csrf,origin=self.url)
        self.assertEqual(code,202,body)
        rid=json.loads(body)['request_id']
        self.assertRegex(rid,r'^[0-9a-f]{32}$')
        self.assertTrue((self.path/'queue'/f'{rid}.json').is_file())
        self.assertEqual(self.call('GET',f'/api/actions/{rid}',cookie=cookie)[0],200)
        self.assertEqual(self.call('GET','/api/actions/../auth.json',cookie=cookie)[0],404)
        self.assertEqual(self.call('GET','/api/actions/'+('f'*32))[0],401)

    def test_tailnet_proxy_origin_and_host_are_explicitly_gated(self):
        with patch.object(server,'TAILSCALE_HOST','project-hub.example.ts.net'):
            self.assertTrue(server.Handler.context(type('R',(),{'headers':{'Host':'project-hub.example.ts.net'}})()))
            self.assertFalse(server.Handler.context(type('R',(),{'headers':{'Host':'evil.example.ts.net'}})()))
            self.assertTrue(server.Handler.origin_ok(type('R',(),{'headers':{'Host':'127.0.0.1:8765','Origin':'https://project-hub.example.ts.net'}})()))
            self.assertFalse(server.Handler.origin_ok(type('R',(),{'headers':{'Host':'127.0.0.1:8765','Origin':'https://evil.example.ts.net'}})()))
        with patch.object(server,'TAILSCALE_HOST',''):
            self.assertFalse(server.Handler.context(type('R',(),{'headers':{'Host':'project-hub.example.ts.net'}})()))

    def test_missing_admin_password_fails_closed(self):
        with patch.object(server,'AUTH_FILE',self.path/'not-installed-auth.json'):
            code,_,body=self.call('POST','/api/login',{'password':'valid-but-not-configured'},origin=self.url)
            self.assertEqual(code,503)
            self.assertIn('не настроен',json.loads(body)['error'])
            code,_,body=self.call('GET','/api/setup-status')
            self.assertFalse(json.loads(body)['configured'])

    def test_brute_force_limit_and_no_session_from_bad_password(self):
        for _ in range(5):
            code,headers,_=self.call('POST','/api/login',{'password':'invalid','otp':'123456'},origin=self.url)
            self.assertEqual(code,401)
            self.assertNotIn('Set-Cookie',headers)
        code,headers,_=self.call('POST','/api/login',{'password':'long-test-password-123','otp':mfa.totp_code(b'12345678901234567890')},origin=self.url)
        self.assertEqual(code,429)
        self.assertNotIn('Set-Cookie',headers)

    def test_2fa_is_required_and_must_match(self):
        base={'password':'long-test-password-123'}
        self.assertEqual(self.call('POST','/api/login',base,origin=self.url)[0],401)
        self.assertEqual(self.call('POST','/api/login',{**base,'otp':'000000'},origin=self.url)[0],401)
        self.assertEqual(self.call('POST','/api/login',{**base,'otp':mfa.totp_code(b'12345678901234567890')},origin=self.url)[0],200)
        with patch.object(server,'MFA_FILE',self.path/'missing-totp.json'):
            self.assertEqual(self.call('POST','/api/login',{**base,'otp':'123456'},origin=self.url)[0],503)
        self.assertEqual(self.call('GET','/api/status')[0],401)

    def test_bounded_web_server_refuses_excess_workers(self):
        self.assertLessEqual(server.BoundedHTTPServer.max_workers,8)
        with server.BoundedHTTPServer(('127.0.0.1',0),server.Handler) as instance:
            acquired=0
            while instance._available.acquire(blocking=False):
                acquired+=1
            self.assertEqual(acquired,8)
            self.assertFalse(instance._available.acquire(blocking=False))
            for _ in range(acquired):instance._available.release()
            self.assertTrue(instance._available.acquire(blocking=False))
            instance._available.release()

    def test_totp_enrollment_does_not_modify_admin_password(self):
        password_file=self.auth.read_bytes()
        self.assertTrue(server.mfa_ready())
        self.assertEqual(self.auth.read_bytes(),password_file)

    def test_totp_vectors_and_bad_record(self):
        from datetime import datetime
        key=b'12345678901234567890'
        self.assertEqual(mfa.totp_code(key,when=59), '287082')
        self.assertEqual(mfa.totp_code(key,when=1111111109), '081804')
        self.assertIsNone(mfa.check_otp('1234567',mfa.read_record(self.mfa)))
        self.assertIsNone(mfa.check_otp('one234',mfa.read_record(self.mfa)))
        with tempfile.TemporaryDirectory() as path:
            link=Path(path)/'totp.json'
            link.symlink_to(self.mfa)
            self.assertIsNone(mfa.read_record(link))

    def test_setup_status_and_invalid_host(self):
        code,_,body=self.call('GET','/api/setup-status')
        self.assertEqual(code,200)
        self.assertTrue(json.loads(body)['configured'])
        self.assertTrue(json.loads(body)['mfa_ready'])
        self.assertEqual(self.call('GET','/api/session',cookie='fake',origin='http://evil.test')[0],401)
        self.assertEqual(self.call('GET','/api/setup-status',origin=self.url)[0],200)

    def test_reject_cross_site_and_oversized(self):
        cookie,csrf=self.login()
        self.assertEqual(self.call('POST','/api/actions',{'action':'restart','container_id':'a'*12},cookie=cookie,csrf=csrf,origin='http://evil.local')[0],403)
        self.assertEqual(self.call('GET','/',origin=self.url)[0],200)

class WorkerTests(unittest.TestCase):
    def test_allowlist_and_refuse_self(self):
        self.assertFalse(worker.authorized_project('project-hub',['project-hub']))
        self.assertFalse(worker.authorized_project('wrcommunity-local',[]))
        self.assertTrue(worker.authorized_project('private-test',['private-test']))
    def test_worker_never_controls_unallowlisted_docker(self):
        from types import SimpleNamespace
        fake={'Id':'a'*64,'Config':{'Labels':{'com.docker.compose.project':'not-allowed'}}}
        def cmd(args,timeout=18):
            self.assertEqual(args[:3],['inspect','--type','container'])
            return SimpleNamespace(returncode=0,stdout=json.dumps([fake]),stderr='')
        with patch.object(worker,'command',side_effect=cmd) as spy,patch.object(worker,'allowed',return_value=['another-project']):
            response=worker.execute({'action':'stop','container_id':'a'*12})
            self.assertFalse(response['ok'])
            self.assertEqual(spy.call_count,1)

    def test_worker_rejects_unlabelled_container(self):
        from types import SimpleNamespace
        fake={'Id':'a'*64,'Config':{'Labels':None}}
        with patch.object(worker,'command',return_value=SimpleNamespace(returncode=0,stdout=json.dumps([fake]),stderr='')) as cmd,patch.object(worker,'allowed',return_value=['demo']):
            response=worker.execute({'action':'restart','container_id':'a'*12})
            self.assertFalse(response['ok'])
            self.assertEqual(cmd.call_count,1)

    def test_worker_uses_fixed_args_for_allowlisted_action(self):
        from types import SimpleNamespace
        fake={'Id':'a'*64,'Config':{'Labels':{'com.docker.compose.project':'demo'}}}
        calls=[]
        def cmd(args,timeout=18):
            calls.append(args)
            if args[0]=='inspect':return SimpleNamespace(returncode=0,stdout=json.dumps([fake]),stderr='')
            return SimpleNamespace(returncode=0,stdout='ok',stderr='')
        with patch.object(worker,'command',side_effect=cmd),patch.object(worker,'allowed',return_value=['demo']):
            response=worker.execute({'action':'restart','container_id':'a'*12})
        self.assertTrue(response['ok'])
        self.assertEqual(calls[1],['restart','--time','8','a'*64])

    def test_validate_action(self):
        for op in ['start','stop','restart','logs']:
            self.assertTrue(worker.valid_request({'action':op,'container_id':'e'*12}))
        for x in [{'action':'remove','container_id':'e'*12},{'action':'start','container_id':'e'*12,'shell':'sh'},{'action':'stop','container_id':'/etc/passwd'}]:
            self.assertFalse(worker.valid_request(x))

if __name__=='__main__':unittest.main()
