#!/usr/bin/env python3
"""Root-operated local password bootstrap. No default password or secrets in argv."""
import getpass
import hashlib
import json
import os
from pathlib import Path
import secrets
import sys

def make_password_record(password: str) -> dict:
    if not isinstance(password,str) or not (12 <= len(password) <= 256):
        raise ValueError('Пароль должен содержать 12–256 символов')
    salt=secrets.token_bytes(16)
    digest=hashlib.scrypt(password.encode('utf-8'),salt=salt,n=16384,r=8,p=1,dklen=32)
    return {'version':1,'algorithm':'scrypt','n':16384,'r':8,'p':1,'salt':salt.hex(),'digest':digest.hex()}

def verify_password(password: str, record: dict) -> bool:
    try:
        if set(record) != {'version','algorithm','n','r','p','salt','digest'} or (record['version'],record['algorithm'],record['n'],record['r'],record['p']) != (1,'scrypt',16384,8,1):return False
        if not isinstance(password,str) or len(password)>256:return False
        salt=bytes.fromhex(record['salt']); digest=bytes.fromhex(record['digest'])
        if len(salt)!=16 or len(digest)!=32:return False
        got=hashlib.scrypt(password.encode('utf-8'),salt=salt,n=16384,r=8,p=1,dklen=32)
        return secrets.compare_digest(got,digest)
    except (ValueError,TypeError,KeyError,MemoryError):return False

def main():
    if os.geteuid()!=0:sys.exit('Команду настройки пароля запустите через root SSH')
    target=Path('/opt/project-hub/private/auth.json')
    if target.parent.is_symlink() or not target.parent.is_dir():sys.exit('Нет безопасной папки private/')
    first=getpass.getpass('Новый пароль Project Hub (минимум 12 символов): ')
    second=getpass.getpass('Повтори пароль: ')
    if first!=second:sys.exit('Пароли не совпадают')
    record=make_password_record(first)
    temp=target.with_name('.auth.'+secrets.token_hex(8))
    flags=os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0)
    fd=os.open(temp,flags,0o640)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as output:
            json.dump(record,output)
            output.write('\n');output.flush();os.fsync(output.fileno())
        os.chown(temp,0,10001)
        os.chmod(temp,0o640)
        os.replace(temp,target)
    finally:temp.unlink(missing_ok=True)
    print('Пароль установлен. Выполни: cd /opt/project-hub && docker compose restart web')
if __name__=='__main__':main()
