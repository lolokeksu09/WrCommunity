#!/usr/bin/env python3
"""Interactive root-only enrollment for TOTP; never takes secret/code via argv."""
from pathlib import Path
import base64
import getpass
import json
import os
import secrets
import sys

ROOT = Path('/opt/project-hub')
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app'))
from mfa import check_otp, read_record


def main():
    if os.geteuid() != 0:
        raise SystemExit('Запусти настройку второго фактора как root на VDS')
    home = ROOT / 'private'
    path = home / 'totp.json'
    if home.is_symlink() or not home.is_dir():
        raise SystemExit('Нет безопасного каталога private/')
    if path.is_symlink() or (path.exists() and path.stat().st_size > 0):
        raise SystemExit('TOTP уже включён. Для замены потребуется отдельная процедура восстановления через SSH.')
    secret = base64.b32encode(secrets.token_bytes(20)).decode().rstrip('=')
    record = {'version': 1, 'algorithm': 'totp-sha1', 'digits': 6, 'period': 30, 'secret': secret}
    print('В приложении 2FAS, Aegis или Google Authenticator добавь ключ вручную.')
    print('Название: Project Hub')
    print('Ключ (НЕ отправляй в чат):', secret)
    print('Тип: TOTP, SHA1, 6 цифр, интервал 30 секунд')
    code = getpass.getpass('Введите 6-значный код из приложения для подтверждения: ')
    if check_otp(code, record) is None:
        raise SystemExit('Неверный код. Файл не изменён; повтори настройку.')
    tmp = home / ('.totp.' + secrets.token_hex(8))
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o640)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(record, handle)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
        os.chown(tmp, 0, 10001)
        os.chmod(tmp, 0o640)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)
    if read_record(path) is None:
        raise SystemExit('TOTP файл не прошёл проверку после записи')
    print('Второй фактор включён. Теперь можно выполнить install.sh.')


if __name__ == '__main__':
    main()
