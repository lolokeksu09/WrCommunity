#!/usr/bin/env python3
"""Root-owned allowlisted Docker actions from a minimal file queue. Never a shell."""
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time
import uuid

BASE=Path('/opt/project-hub')
QUEUE=BASE/'queue'
PROCESSING=BASE/'processing'
RESULTS=BASE/'state/actions'
ALLOWED=BASE/'private/managed-projects.json'
OPS={'start','stop','restart','logs'}
ID=re.compile(r'^[a-f0-9]{12}(?:[a-f0-9]{52})?$')
REQUEST_ID=re.compile(r'^[a-f0-9]{32}$')

def valid_request(item):
    return (isinstance(item,dict) and set(item)=={'action','container_id'} and
            item.get('action') in OPS and isinstance(item.get('container_id'),str) and bool(ID.fullmatch(item['container_id'])))

def authorized_project(name, allow):
    return (isinstance(name,str) and bool(re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}',name))
            and name!='project-hub' and name in allow)

def allowed():
    try:
        with ALLOWED.open('rb') as f:raw=f.read(4097)
        if len(raw)>4096: return []
        j=json.loads(raw)
        if not isinstance(j,list) or len(j)>20:return []
        return [x for x in j if isinstance(x,str) and re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}',x)]
    except (OSError,ValueError):return []

def command(args,timeout=18):
    return subprocess.run(['docker',*args],capture_output=True,text=True,timeout=timeout,check=False)

def execute(request):
    if not valid_request(request):return {'ok':False,'message':'Отклонён недопустимый запрос'}
    cid=request['container_id']; action=request['action']
    try:
        inspected=command(['inspect','--type','container',cid],timeout=8)
        if inspected.returncode!=0:return {'ok':False,'message':'Контейнер не найден'}
        data=json.loads(inspected.stdout)
        if len(data)!=1 or not isinstance(data[0],dict):raise ValueError('invalid inspect')
        info=data[0]
        full=info.get('Id','')
        if not isinstance(full,str) or len(full)!=64 or not full.startswith(cid):return {'ok':False,'message':'Контейнер не совпадает с ID'}
        config=info.get('Config') or {}
        labels=config.get('Labels') or {}
        if not isinstance(config,dict) or not isinstance(labels,dict):return {'ok':False,'message':'Некорректные метаданные контейнера'}
        project=labels.get('com.docker.compose.project','')
        if not authorized_project(project,allowed()):return {'ok':False,'message':'Проект не разрешён администратором VDS'}
        if action=='logs':
            p=command(['logs','--tail','80','--since','1h',full],timeout=12)
            return {'ok':p.returncode==0,'message':'Лог контейнера' if p.returncode==0 else 'Не удалось прочитать лог',
                    'output':(p.stdout+'\n'+p.stderr)[-16000:]}
        opts={'start':['start',full], 'stop':['stop','--time','8',full], 'restart':['restart','--time','8',full]}
        p=command(opts[action],timeout=18)
        return {'ok':p.returncode==0,'message':('Команда выполнена' if p.returncode==0 else 'Docker отклонил операцию'),
                'output':(p.stdout+'\n'+p.stderr)[-3000:]}
    except (ValueError,OSError,subprocess.TimeoutExpired,KeyError,TypeError):
        return {'ok':False,'message':'Ошибка выполнения Docker. Проверь журнал сервиса.'}

def atomic_result(rid,result):
    RESULTS.mkdir(parents=True,exist_ok=True)
    tmp=RESULTS/f'.{rid}.{uuid.uuid4().hex}.tmp'
    fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o640)
    try:
        with os.fdopen(fd,'w') as f:
            json.dump({'request_id':rid,**result,'finished_at':int(time.time())},f,ensure_ascii=False)
            f.write('\n');f.flush();os.fsync(f.fileno())
        os.chown(tmp,0,10001)
        os.chmod(tmp,0o640)
        os.replace(tmp,RESULTS/f'{rid}.json')
    finally:tmp.unlink(missing_ok=True)

def consume(path):
    rid=path.stem
    if not REQUEST_ID.fullmatch(rid):return
    claim=PROCESSING/path.name
    try:os.replace(path,claim)
    except FileNotFoundError:return
    try:
        fd=os.open(claim,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
        with os.fdopen(fd,'rb') as f:
            st=os.fstat(f.fileno())
            if not stat.S_ISREG(st.st_mode) or st.st_size>4096 or st.st_nlink!=1 or st.st_uid!=10001:
                raise ValueError('Invalid file provenance')
            data=json.loads(f.read(4097))
        result=execute(data)
    except (OSError,ValueError,TypeError):result={'ok':False,'message':'Запрос повреждён или недопустим'}
    atomic_result(rid,result)
    claim.unlink(missing_ok=True)

def main():
    if os.geteuid()!=0:raise SystemExit('This worker requires root and local systemd policy')
    PROCESSING.mkdir(mode=0o700,parents=True,exist_ok=True)
    RESULTS.mkdir(mode=0o750,parents=True,exist_ok=True)
    for stale in sorted(PROCESSING.glob('*.json')):
        if REQUEST_ID.fullmatch(stale.stem):
            if not (RESULTS/stale.name).exists():atomic_result(stale.stem,{'ok':False,'message':'Операция прервана. Проверь состояние контейнера перед повтором.'})
            stale.unlink(missing_ok=True)
    for path in sorted(QUEUE.glob('*.json'))[:20]:consume(path)
    # Expire old results, preserving evidence for seven days.
    now=time.time()
    for path in RESULTS.glob('*.json'):
        if REQUEST_ID.fullmatch(path.stem) and not path.is_symlink() and path.is_file():
            if now-path.stat().st_mtime>7*86400:path.unlink(missing_ok=True)

if __name__=='__main__':main()
