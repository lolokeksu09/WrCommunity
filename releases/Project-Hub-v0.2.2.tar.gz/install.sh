#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Run as root on VDS' >&2; exit 1; fi
cd /opt/project-hub
sha256sum --check --status SHA256SUMS.txt || { echo 'Package integrity check failed' >&2; exit 1; }
for f in collector.py app/server.py app/index.html app/app.js app/app.css compose.yml Dockerfile tools/worker.py tools/password.py tools/mfa_setup.py app/mfa.py; do
  [[ -f "$f" && ! -L "$f" ]] || { echo "Missing/unsafe $f" >&2; exit 1; }
done
for c in docker python3 systemctl; do command -v "$c" >/dev/null; done
docker compose version
install -d -o root -g root -m 0755 state
install -d -o root -g 10001 -m 0750 state/actions
install -d -o root -g 10001 -m 0750 private
install -d -o 10001 -g 10001 -m 0700 queue
install -d -o root -g root -m 0700 processing
if [[ ! -e private/auth.json ]]; then
  # Empty config never grants login; setup is a separate interactive SSH step.
  install -o root -g 10001 -m 0640 /dev/null private/auth.json
fi
if [[ -L private/totp.json ]]; then echo 'Unsafe 2FA file' >&2; exit 1; fi
if [[ ! -e private/totp.json ]]; then
  install -o root -g 10001 -m 0640 /dev/null private/totp.json
fi
if ! python3 - <<'VERIFY_2FA'
import os,sys
sys.path.insert(0,'/opt/project-hub/app')
from pathlib import Path
from mfa import read_record
record=read_record(Path('/opt/project-hub/private/totp.json'))
assert record is not None, 'TOTP enrollment needed: python3 /opt/project-hub/tools/mfa_setup.py'
st=os.stat('/opt/project-hub/private/totp.json',follow_symlinks=False)
assert st.st_uid==0 and st.st_gid==10001 and st.st_mode & 0o077 == 0o040, 'Unsafe TOTP file permissions'
print('2FA enrollment verified')
VERIFY_2FA
then
  echo 'Install deferred safely. Existing web container has NOT been restarted.' >&2
  exit 1
fi
if [[ ! -f private/managed-projects.json ]]; then
  printf '[]\n' > private/managed-projects.json
  chown root:root private/managed-projects.json
  chmod 0644 private/managed-projects.json
fi
for f in systemd/project-hub-collector.service systemd/project-hub-collector.timer systemd/project-hub-worker.service systemd/project-hub-worker.timer; do
  install -o root -g root -m 0644 "$f" /etc/systemd/system/
done
systemctl daemon-reload
systemctl enable --now project-hub-collector.timer project-hub-worker.timer
systemctl start project-hub-collector.service
[[ -f state/status.json ]] || { echo 'Collector failed' >&2; exit 1; }
docker compose up -d --build
for attempt in $(seq 1 20); do
  if curl -fsS --max-time 2 http://127.0.0.1:8765/healthz >/dev/null; then
    echo 'Project Hub v0.2.2 is healthy on VDS localhost:8765';
    echo '2FA configured. Existing admin password retained.';
    echo 'Access via SSH tunnel or protected HTTPS Funnel. Edit private/managed-projects.json for allowlisted Docker Compose projects.';
    exit 0
  fi
  sleep 1
done
echo 'Project Hub did not respond on localhost:8765' >&2
exit 1
