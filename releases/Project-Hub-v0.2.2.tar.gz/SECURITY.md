# Project Hub v0.2.2 — security boundaries

## Exposure and responsibility

Tailscale **Funnel** exposes the authentication screen to the entire internet. It is **not private Serve**. Project Hub requires an admin password **and** a TOTP one-time code. This provides another factor for account takeover but does not eliminate DDoS, vulnerability exploitation, phishing, or origin-server compromise. Do not enable arbitrary shell access or mount Docker's socket into the web container.

The host binds the web app only to `127.0.0.1:8765`; Tailscale Funnel terminates public TLS and forwards to that loopback endpoint. An old, already running 0.2.1 container is **not** protected by the new 2FA until the new image is installed and verified.

## Authentication

- Existing password remains in `/opt/project-hub/private/auth.json`, stored as salted scrypt. The update does not overwrite it.
- A 20-byte random TOTP key is enrolled locally by root through `tools/mfa_setup.py`: SHA1, 6 digits, 30 seconds, +/- one step for clock skew. Configuration lives in `/opt/project-hub/private/totp.json` (`root:10001`, `0640`). No TOTP secrets are included in artifacts, Docker environment, HTML, API responses, or version control.
- Enrollment verifies the first code **before** activating the second factor. If enrollment fails, the existing web container remains available and the new version is not deployed.
- Password + OTP are required on every login. Missing/invalid OTP never creates a session. Generic 401 on invalid credentials.
- A 5-failed-attempts/15-minute source-IP limit reduces online guessing. Due to Funnel's proxying, multiple clients may share one apparent IP; an attacker can temporarily lock out the legitimate admin. Limits are in-memory and reset on web restart. A separate identity-aware gate is recommended if public use grows.
- HttpOnly, SameSite=Strict cookies; `Secure` when signing in over the configured Tailscale HTTPS hostname. 4-hour absolute / 15-minute idle sessions, server-side session table bounded to 32, CSRF token for mutations, host and origin validation, logout revocation. Sessions reset on web restart.
- All static assets and `/healthz` remain unauthenticated. Other APIs require login. Response headers restrict CSP, framing, MIME sniffing, referrer, cross-origin resource sharing. HSTS is sent on the trusted HTTPS hostname.
- HTTP connection slots limited to 8, read timeout 8 seconds. Resource exhaustion remains possible from a large-volume public attack; if availability matters, use an identity-aware upstream gate or disable Funnel.

## Docker operations

- The web container runs as UID 10001, read-only, no Docker socket, no root shell and no privileged process. It can enqueue requests in a bounded directory.
- A separate root-owned systemd worker validates regular queue files, container ID and a root-owned Compose project allowlist; it excludes project `project-hub`. Only `start`, `stop`, `restart`, and bounded `logs` are supported. No delete/prune, arbitrary command execution, or dynamic compose management.
- If the web container itself is compromised, the attacker can enqueue actions against **already allowlisted** projects. Avoid putting critical services on the allowlist and consider separating worker privileges further before expanding.
- Audit logs may contain application secrets; only the admin may request them and results expire after 7 days.

## Recovery

- Losing your authenticator: use the root SSH console / hosting provider console for manual recovery. Never share `totp.json` or the authenticator seed with anyone; store the seed in a secure encrypted backup if desired. A new enrollment must revoke all web sessions via `docker compose restart web`.
- Suspected compromise: temporarily run `tailscale funnel --https=443 off` on VDS (public site becomes unavailable), inspect logs, change the password and TOTP key, then restart web to revoke all sessions. Back up before deleting any data.
- A completed local unit test, Docker image build, or HTTPS `200` is not evidence of an independent penetration test or live two-factor login. Verify sign-in manually after deployment.
